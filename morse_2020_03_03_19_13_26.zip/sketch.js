var mc1 = "";
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
function keyPressed()
{
  if(key == 'a')
  {
     mc1= " ._ ";
    console.log(mc1)
    
    }

  {if(key == 'b' )
  {
    mc1 = " _... ";
   console.log(mc1) 
    }
}
{if(key == 'c' )
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }
}
{if(key == 'd' )
  {
    mc1 = "_..";
   console.log(mc1) 
    }
}{if(key == 'e' )
  {
    mc1 = ".";
   console.log(mc1) 
    }
}{if(key == 'f' )
  {
    mc1 = "..-.";
   console.log(mc1) 
    }
}{if(key == 'g' )
  {
    mc1 = "--.";
   console.log(mc1) 
    }
}{if(key == 'h' )
  {
    mc1 = "....";
   console.log(mc1) 
    }
}{if(key == 'i' )
  {
    mc1 = "..";
   console.log(mc1) 
    }
}{if(key == 'j' )
  {
    mc1 = ".---";
   console.log(mc1) 
    }
}{if(key == 'k' )
  {
    mc1 = "-.-";
   console.log(mc1) 
    }
}{if(key == 'l' )
  {
    mc1 = ".-.."
   console.log(mc1) 
    }
}{if(key == 'm')
  {
    mc1 = "--"
   console.log(mc1) 
    }
}{if(key == 'n')
  {
    mc1 = "-.";
   console.log(mc1) 
    }
}{if(key == 'o')
  {
    mc1 = "---";
   console.log(mc1) 
    }}
  {if(key == 'p')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
   {if(key == 'q')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
    {if(key == 'r')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
     {if(key == 's')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
      {if(key == 't')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
       {if(key == 'u')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
        {if(key == 'v')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
         {if(key == 'w')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
          {if(key == 'x')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }}
           {if(key == 'y')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }
            {if(key == 'z')
  {
    mc1 = "-.-.";
   console.log(mc1) 
    }
  
}}}

